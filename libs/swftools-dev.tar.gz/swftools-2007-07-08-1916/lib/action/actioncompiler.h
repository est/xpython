#ifndef __actioncompiler_h__
#define __actioncompiler_h__

int compileSWFActionCode(const char *script, int version, void**data, int*len);

#endif

