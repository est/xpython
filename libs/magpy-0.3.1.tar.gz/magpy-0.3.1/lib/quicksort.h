#ifndef __quicksort_h__
#define __quicksort_h__
void quicksort (int*array, int n);
#endif
