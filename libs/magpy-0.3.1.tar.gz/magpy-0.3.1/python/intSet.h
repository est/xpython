#ifndef __intset_h__
#define __intset_h__

PyObject* intSet_new();
PyObject* intSet_fromarray(int*values, int num);
PyObject* f_makeIntSet(PyObject* _self, PyObject* args, PyObject* kwargs);
void initintSet(void);

int writeIntArray(char*destfile, int*numbers, int num);
int* readIntArray(char*sourcefile, int*num, int**index);


#endif
