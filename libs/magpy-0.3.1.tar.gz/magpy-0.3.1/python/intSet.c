/*****************************************************************************

  Copyright (c) 2001 Zope Corporation and Contributors. All Rights Reserved.
  
  This software is subject to the provisions of the Zope Public License,
  Version 2.0 (ZPL).  A copy of the ZPL should accompany this distribution.
  THIS SOFTWARE IS PROVIDED "AS IS" AND ANY AND ALL EXPRESS OR IMPLIED
  WARRANTIES ARE DISCLAIMED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
  WARRANTIES OF TITLE, MERCHANTABILITY, AGAINST INFRINGEMENT, AND FITNESS
  FOR A PARTICULAR PURPOSE
  
 ****************************************************************************/

static char intSet_module_documentation[] = 
""
"\n$Id: intSet.c,v 1.3 2006/04/19 15:09:34 kramm Exp $"
;

#include <Python.h>
#include "quicksort.h"
#include "intSet.h"

#define UNLESS(E) if(!(E))
#define RETURN_NONE Py_INCREF(Py_None); return Py_None

#define MIN_INTSET_ALLOC 8

#define INTSET_DATA_TYPE int
#define INTSET_DATA_FLAG "l"

typedef struct {
  PyObject_HEAD;
  int size, len;
  INTSET_DATA_TYPE *data;
} intSet;


staticforward PyTypeObject intSetType;

static PyObject * intSet_has_key(PyObject*_self, PyObject *args)
{
    intSet*self = (intSet*)_self;
    int min, max, i, l;
    INTSET_DATA_TYPE k, key;

    if(!PyArg_ParseTuple(args,INTSET_DATA_FLAG,&key)) 
	return NULL;

    for(min=0, max=self->len, i=max/2, l=max; i != l; l=i, i=(min+max)/2)
    {
	k=self->data[i];
	if(k == key) return PyInt_FromLong(1);
	if(k > key) max=i;
	else min=i;
    }
    return PyInt_FromLong(0);
}


static int intSet_grow(intSet*self, int l)
{
    int g;
    INTSET_DATA_TYPE *data;

    if(self->data)
    {
	g=self->size*2;
	if(g < l) g=l;
	UNLESS(data=realloc(self->data, sizeof(INTSET_DATA_TYPE)*g))
	{
	    PyErr_NoMemory();
	    return -1;
	}
	self->data=data;
	self->size=g;
    } else {
	g=l < MIN_INTSET_ALLOC ? MIN_INTSET_ALLOC : l;
	UNLESS(self->data=malloc(sizeof(INTSET_DATA_TYPE)*g))
	{
	    PyErr_NoMemory();
	    return -1;
	}
	self->size=g;
    }
    return 0;
}  

static INTSET_DATA_TYPE intSet_modify(intSet*self, INTSET_DATA_TYPE ikey, int add)
{
    int min, max, i, l;
    INTSET_DATA_TYPE *data, k;
    
    data=self->data;

    for(min=0, max=self->len, i=max/2, l=max; i != l; l=i, i=(min+max)/2)
    {
	k=data[i];
	if(k == ikey) 
	{
	    if(!add)
	    {
		data+=i;
		self->len--;
		if(i < (self->len))
		  memmove(data, data+1, (self->len-i)*sizeof(INTSET_DATA_TYPE));
	    }
	    return 0;
	}
	if(k > ikey) max=i;
	else min=i;
    }
    if(!add) return 0;
    if(self->len >= self->size && intSet_grow(self,self->len+1) < 0)
	return -1;
    if(max != i) i++;
    data=self->data+i;
    if(self->len > i)
	memmove(data+1,data,(self->len-i)*sizeof(INTSET_DATA_TYPE));
    *data=ikey;
    self->len++;
    return ikey;
}

static PyObject * intSet_insert(PyObject*_self, PyObject *args)
{
    intSet*self = (intSet*)_self;

    INTSET_DATA_TYPE key;

    UNLESS(PyArg_ParseTuple(args,INTSET_DATA_FLAG,&key)) return NULL;

    if(intSet_modify(self, key, 1) < 0) return NULL;
    RETURN_NONE;
}

static PyObject * intSet_remove(PyObject*_self, PyObject *args)
{
    intSet*self = (intSet*)_self;

    INTSET_DATA_TYPE key;

    UNLESS(PyArg_ParseTuple(args,INTSET_DATA_FLAG,&key)) return NULL;

    if(intSet_modify(self, key, 0) < 0) return NULL;
    RETURN_NONE;
}
  
static PyObject * intSet_clear(PyObject*_self, PyObject *args)
{
    intSet*self = (intSet*)_self;

    self->len=0;
    RETURN_NONE;
}

char* setError(char*format, ...)
{
    char buf[1024];
    int l;
    va_list arglist;
    va_start(arglist, format);
    vsprintf(buf, format, arglist);
    va_end(arglist);
    l = strlen(buf);
    while(l && buf[l-1]=='\n') {
	buf[l-1] = 0;
	l--;
    }
    return strdup(buf);
}

int* readIntArray(char*sourcefile, int*num, int**index)
{
    FILE*fi;
    int filelen;
    if(!(fi = fopen(sourcefile, "rb"))) {
	PyErr_SetString(PyExc_Exception, setError("Couldn't open file %s", sourcefile));
	return 0;
    }
    fseek(fi, 0, SEEK_END);
    filelen = ftell(fi);
    fseek(fi, 0, SEEK_SET);
    char*data = (char*)malloc(filelen);
    fread(data, filelen, 1, fi);
    fclose(fi);
    int count = 0;
    int t = 0;
    while(t<filelen) {
	count ++;
	while(data[t]!=2 && data[t]!=';' && t<filelen)
	    t++;
	if(t == filelen)
	    break;
	t++;
    }
    int*numbers = (int*)malloc(sizeof(int)*count);
    if(index) {
	*index = (int*)malloc(sizeof(int)*count);
    }
    count = 0;
    t = 0;
    int pos = 0;
    while(t<filelen) {
	numbers[count] = atoi(&data[t]);
	if(index) {
	    (*index)[count] = pos;
	}
	count++;
	while(data[t]!=2 && data[t]!=';' && t<filelen)
	    t ++;
	if(t == filelen)
	    break;
	if(data[t]==2)
	    pos++;
	t++;
    }
    *num = count;
    free(data);
    return numbers;
}

int writeIntArray(char*destfile, int*numbers, int num)
{
    FILE*fi = fopen(destfile, "wb");
    if(!fi) {
	PyErr_SetString(PyExc_Exception, setError("Couldn't write file %s", destfile));
	return 0;
    }
    int t;
    for(t=0;t<num;t++) {
	fprintf(fi, "%d\2", numbers[t]);
    }
    fclose(fi);
    return 1;
}


PyObject* intSet_new()
{
    intSet *r = 0;
    r = PyObject_New(intSet, &intSetType);
    r->len = 0; r->size = 0; r->data = 0;
    return (PyObject*)r;
}

PyObject* intSet_fromarray(INTSET_DATA_TYPE*values, int num)
{
    intSet *r = PyObject_New(intSet, &intSetType);
    r->len = num; 
    r->size = num; 
    r->data = values;

    quicksort (r->data, num);

    return (PyObject*)r;
}

PyObject* intSet_load(char*filename)
{
    int num;
    int*numbers = readIntArray(filename, &num, 0);
    
    intSet *r = PyObject_New(intSet, &intSetType);
    r->len = num; 
    r->size = num; 
    r->data = numbers;
    return (PyObject*)r;
}

static PyObject * intSet_set_operation(PyObject* _self, PyObject *other, int cpysrc, int cpyboth, int cpyoth)
{
    intSet*self = (intSet*)_self;
    intSet *r=0, *o;
    int i, l, io, lo;
    INTSET_DATA_TYPE *d, *od, v, vo;
    
    if(other->ob_type != self->ob_type)
    {
	PyErr_SetString(PyExc_TypeError, "intSet set operations require same-type operands");
	return NULL;
    }
    o=(intSet*)(other);

    od=o->data;

    d=self->data;

    r = (intSet*)intSet_new();

    for(i=0, l=self->len, io=0, lo=o->len; i < l && io < lo; )
      {
	v=d[i];
	vo=od[io];
	if(v < vo)
	  {
	    if(cpysrc)
	      {
		if(r->len >= r->size && intSet_grow(r,0) < 0) goto err;
		r->data[r->len]=v;
		r->len++;
	      }
	    i++;
	  }
	else if(v==vo)
	  {
	    if(cpyboth)
	      {
		if(r->len >= r->size && intSet_grow(r,0) < 0) goto err;
		r->data[r->len]=v;
		r->len++;
	      }
	    i++;
	    io++;
	  }
	else
	  {
	    if(cpyoth)
	      {
		if(r->len >= r->size && intSet_grow(r,0) < 0) goto err;
		r->data[r->len]=vo;
		r->len++;
	      }
	    io++;
	  }
      }
    if(cpysrc && i < l)
      {
	l-=i;
	if(r->len+l > r->size && intSet_grow(r,r->len+l) < 0) goto err;
	memcpy(r->data+r->len, d+i, l*sizeof(INTSET_DATA_TYPE));
	r->len += l;
      }
    else if(cpyoth && io < lo)
      {
	lo-=io;
	if(r->len+lo > r->size && intSet_grow(r,r->len+lo) < 0) goto err;
	memcpy(r->data+r->len, od+io, lo*sizeof(INTSET_DATA_TYPE));
	r->len += lo;
      }

    return (PyObject*)(r);

err:
    Py_DECREF(r);
    return NULL;
}

static PyObject * intSet_add(PyObject *self, PyObject *other)
{
  return intSet_set_operation(self,other,1,1,1);
}

static PyObject * intSet_union(PyObject*self, PyObject *args)
{
  PyObject *other;

  UNLESS(PyArg_ParseTuple(args,"O",&other)) return NULL;
  
  return intSet_set_operation(self,other,1,1,1);
}

static PyObject * intSet_intersection(PyObject*self, PyObject *args)
{
  PyObject *other;

  UNLESS(PyArg_ParseTuple(args,"O",&other)) return NULL;
  return intSet_set_operation(self,other,0,1,0);
}

static PyObject * intSet_difference(PyObject*self, PyObject *args)
{
  PyObject *other;

  UNLESS(PyArg_ParseTuple(args,"O",&other)) return NULL;
  return intSet_set_operation(self,other,1,0,0);
}

static struct PyMethodDef intSet_methods[] = {
  {"has_key",	   (PyCFunction)intSet_has_key,	     METH_VARARGS, "has_key(id) -- Test whether the set has the given id"},
  {"insert",	   (PyCFunction)intSet_insert,	     METH_VARARGS, "insert(id,[ignored]) -- Add an id to the set"},
  {"remove",	   (PyCFunction)intSet_remove,	     METH_VARARGS, "remove(id) -- Remove an id from the set"},
  {"clear",	   (PyCFunction)intSet_clear,	     METH_VARARGS, "clear() -- Remove all of the ids from the set"},
  {"union",	   (PyCFunction)intSet_union,	     METH_VARARGS, "union(other) -- Return the union of the set with another set"},
  {"intersection", (PyCFunction)intSet_intersection, METH_VARARGS, "intersection(other) -- Return the intersection of the set with another set"},
  {"difference",   (PyCFunction)intSet_difference,   METH_VARARGS, "difference(other) -- Return the difference of the set with another set"},
  {NULL,	   NULL}
};

static void intSet_dealloc(PyObject*_self)
{
    intSet*self = (intSet*)_self;
    free(self->data);self->data = 0;self->len = 0;self->size = 0;
    PyObject_Del(self);
}

static PyObject * intSet_getattr(PyObject*_self, char*name)
{
    return Py_FindMethod(intSet_methods, _self, name);
}

/* Code to handle accessing intSet objects as sequence objects */

static int intSet_length(PyObject*_self)
{
    intSet*self = (intSet*)_self;
    return self->len;
}

static PyObject *
intSet_repeat(PyObject*_self, int n)
{
    PyErr_SetString(PyExc_TypeError, "intSet objects do not support repetition");
    return NULL;
}

static PyObject *
intSet_item(PyObject*_self, int i)
{
    intSet*self = (intSet*)_self;
    PyObject *e;

    if(i >= 0 && i < self->len)
      return PyInt_FromLong(self->data[i]);
    UNLESS(e=PyInt_FromLong(i)) goto err;
    PyErr_SetObject(PyExc_IndexError, e);
    Py_DECREF(e);
err:
    return NULL;
}

static PyObject * intSet_slice(PyObject*_self, int ilow, int ihigh)
{
    PyErr_SetString(PyExc_TypeError, "intSet objects do not support slicing");
    return NULL;
}

static int
intSet_ass_item(PyObject*_self, int i, PyObject *v)
{
    PyErr_SetString(PyExc_TypeError, "intSet objects do not support item assignment");
    return -1;
}

static int
intSet_ass_slice(PyListObject *self, int ilow, int ihigh, PyObject *v)
{
    PyErr_SetString(PyExc_TypeError, "intSet objects do not support slice assignment");
    return -1;
}

PyObject* f_makeIntSet(PyObject* _self, PyObject* args, PyObject* kwargs)
{
    PyObject*list = 0;
    static char *kwlist[] = {"values", NULL};
    if (!PyArg_ParseTupleAndKeywords(args, kwargs, "|O", kwlist, &list))
	return NULL;

    intSet*self = (intSet*)intSet_new();
    return (PyObject*)self;
}


static PySequenceMethods intSet_as_sequence = {
    (inquiry)intSet_length,		/*sq_length*/
    (binaryfunc)intSet_add,		/*sq_concat*/
    (intargfunc)intSet_repeat,		/*sq_repeat*/
    (intargfunc)intSet_item,		/*sq_item*/
    (intintargfunc)intSet_slice,		/*sq_slice*/
    (intobjargproc)intSet_ass_item,	/*sq_ass_item*/
    (intintobjargproc)intSet_ass_slice,	/*sq_ass_slice*/
};

static PyTypeObject intSetType = {
    PyObject_HEAD_INIT(NULL)
    ob_size: 0,
    tp_name: "intSet",
    tp_basicsize: sizeof(intSet),
    tp_itemsize: 0,
    tp_dealloc: (destructor)intSet_dealloc,
    tp_print: (printfunc)0,
    tp_getattr: (getattrfunc)intSet_getattr,
    tp_setattr: (setattrfunc)0,
    tp_compare: (cmpfunc)0,
    tp_repr: (reprfunc)0,
    tp_as_number: 0,
    tp_as_sequence: &intSet_as_sequence,
    tp_as_mapping: 0,
    tp_hash: (hashfunc)0,
    tp_call: (ternaryfunc)0,
    tp_str: (reprfunc)0,
};

static struct PyMethodDef module_methods[] = {
    {"makeIntSet", (PyCFunction)f_makeIntSet, METH_KEYWORDS, "Create a new int set"},
    {0,0,0,0}
};

void initintSet(void)
{
    PyObject *m, *d;
    
    intSetType.ob_type = &PyType_Type;

    m = Py_InitModule4("intSet", module_methods, intSet_module_documentation, (PyObject*)NULL, PYTHON_API_VERSION);

    /* Check for errors */
    if (PyErr_Occurred())
	Py_FatalError("can't initialize module intSet");
}
