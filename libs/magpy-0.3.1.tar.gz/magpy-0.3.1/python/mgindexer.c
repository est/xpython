#include <stdlib.h>
#include <stdio.h>
#undef _POSIX_C_SOURCE
#include <Python.h>
#include "intSet.h"
#include "messages.h"
#include "words.h"

static char* strf(char*format, ...)
{
    char buf[1024];
    int l;
    va_list arglist;
    va_start(arglist, format);
    vsprintf(buf, format, arglist);
    va_end(arglist);
    return strdup(buf);
}
#define PY_ERROR(s,args...) (PyErr_SetString(PyExc_Exception, strf(s, ## args)),NULL)
#define PY_NONE Py_BuildValue("s", 0)

//---------------------------------------------------------------------


//=====================================================================

void cleanup(char*dir, char*name)
{
    char*extensions[] = {
	"invf","invf.dict","invf.idx","text.idx","trace",
	"invf.chunk","invf.dict.blocked","text","text.idx.wgt","weight",
	"invf.chunk.trans","invf.dict.hash","text.dict","text.stats","weight.approx","numidx","numidx2"
    };
    int t;
    for(t=0;t<sizeof(extensions)/sizeof(extensions[0]);t++) {
	char filename[256];
	sprintf(filename, "%s/%s.%s", dir, name, extensions[t]);
	unlink(filename);
    }
}

void cleanup_unused(char*dir, char*name)
{
    char*extensions[] = {
	"invf.idx","text.stats","text.idx","trace",
	"weight", "invf.chunk","invf.chunk.trans","invf.dict.hash"
    };
    int t;
    for(t=0;t<sizeof(extensions)/sizeof(extensions[0]);t++) {
	char filename[256];
	sprintf(filename, "%s/%s.%s", dir, name, extensions[t]);
	unlink(filename);
    }
}

void makeindex(char*sourcefile,char*dir,char*name, int stem)
{
    char buf[1024];
    int store_chartab = 1;
    cleanup(dir,name);
    set_basepath (dir);

    //export MGDATA=data
    //mkdir -p data/alice

#ifdef WIN32
    mkdir(dir);
#else
    mkdir(dir, 0777);
#endif

    if(store_chartab) {
	sprintf(buf, "%s/%s.chartab", dir,name);
	FILE*fi = fopen(buf, "wb");
	if(fi) {
	    fwrite(getAllowedCharacters(), 1, 256, fi);
	    fclose(fi);
	}
    }

    // mg_passes -f alice -2 -m 32 -s 3 -G -t 10 -T1 -I1
    msg_prefix="";Message("mg_passes -f alice -2 -m 32 -s <stem> -t 10 -T1 -I1\n");
    char* opt1[] = {"mg_passes", "-f",name,"-2","-m","32","-s",stem?"3":"1","-t","10","-T1","-I1", sourcefile};
    mg_passes_main(sizeof(opt1)/sizeof(opt1[0]), opt1);
    //system("./mg_passes -f alice -2 -m 32 -s 3 -t 10 -T1 -I1 sourcefile");

    // mg_perf_hash_build -f alice
    msg_prefix="";Message("mg_perf_hash_build -f alice\n");
    char* opt2[] = {"mg_perf_hash_build", "-f", name};
    mg_perf_hash_build_main(sizeof(opt2)/sizeof(opt2[0]), opt2);

    // Note: Set -S so novel words can be encoded, as this will happen if mgmerge is used.
    // mg_compression_dict -f alice -S
    msg_prefix="";Message("mg_compression_dict -f alice -S\n");
    char* opt3[] = {"mg_compression_dict", "-f", name, "-S"};
    mg_compression_dict_main(sizeof(opt3)/sizeof(opt3[0]), opt3);
    //system("./mg_compression_dict -f alice -S");
   
    // mg_passes -f alice -2 -c 3 -t 10 -T2 -I2
    msg_prefix="";Message("mg_passes -f alice -2 -c 3 -t 10 -T2 -I2\n");
    char* opt4[] = {"mg_passes", "-f", name, "-2", "-c", "3", "-t", "10", "-T2", "-I2", sourcefile};
    mg_passes_main(sizeof(opt4)/sizeof(opt4[0]), opt4);

    // mg_weights_build -f alice -b 6
    msg_prefix="";Message("mg_weights_build -f alice -b 6\n");
    char* opt5[] = {"mg_weights_build", "-f", name, "-b", "6"};
    mg_weights_build_main(sizeof(opt5)/sizeof(opt5[0]), opt5);

    // mg_invf_dict -f alice -b 4096
    msg_prefix="";Message("mg_invf_dict -f alice -b 4096\n");
    char* opt6[] = {"mg_invf_dict", "-f", name, "-b", "4096"};
    mg_invf_dict_main(sizeof(opt6)/sizeof(opt6[0]), opt6);

    // mgstat -f alice -E
    if(getVerbosity()) {
	msg_prefix="";Message("mgstat -f alice -E\n");
	char* opt7[] = {"mgstat", "-f", name, "-E"};
	mgstat_main(sizeof(opt7)/sizeof(opt7[0]), opt7);
    }

done:
    set_basepath(0);

    cleanup_unused(dir,name);

}

static PyObject* f_makeindex(PyObject* self, PyObject* args, PyObject* kwargs)
{
    int stem = 0;
    static char *kwlist[] = {"source", "dir", "name", "stem", NULL};
    char*sourcefile=0,*dir=0,*name=0;
    if (!PyArg_ParseTupleAndKeywords(args, kwargs, "sss|i", kwlist, &sourcefile, &dir, &name, &stem))
	return NULL;

    setAllowedCharacters(allowedchars_alphanumeric);
    makeindex(sourcefile,dir,name,stem);
    
    return PY_NONE;
}

static PyObject* f_makeClassIndex(PyObject* self, PyObject* args, PyObject* kwargs)
{
    static char *kwlist[] = {"source", "dir", "name", NULL};
    char*sourcefile=0,*dir=0,*name=0;
    size_t filelen;
    if (!PyArg_ParseTupleAndKeywords(args, kwargs, "sss", kwlist, &sourcefile, &dir, &name))
	return NULL;
    
    setAllowedCharacters(allowedchars_semicolon);
    makeindex(sourcefile,dir,name,0);

    return PY_NONE;
   
    /*if (!(phd = gen_hash_func (idh.dict_size, starts, r)))
      FatalError (1, "Unable to generate hash function");
    if (write_perf_hash_data (hash, phd) == -1)
      FatalError (1, "Unable to write hash function");
    fclose (dict);
    fclose (hash);*/
}


typedef struct posval {
    int pos;
    int val;
} posval_t;

int compare_pos(const void*_a, const void*_b)
{
    posval_t*a = (posval_t*)_a;
    posval_t*b = (posval_t*)_b;
    return a->val - b->val;
}

static PyObject* f_makeNumIndex(PyObject* self, PyObject* args, PyObject* kwargs)
{
    static char *kwlist[] = {"source", "dir", "name", NULL};
    char*sourcefile=0,*dir=0,*name=0;
    size_t filelen;
    if (!PyArg_ParseTupleAndKeywords(args, kwargs, "sss", kwlist, &sourcefile, &dir, &name))
	return NULL;
   
    cleanup(dir,name);

    int t;
    int num = 0;
    int*positions=0;
    int*numbers = readIntArray(sourcefile, &num, &positions);
    if(!numbers)
	return 0;
    
    posval_t*s2 = (posval_t*)malloc(sizeof(posval_t)*num);
    for(t=0;t<num;t++) {
	s2[t].pos = positions[t];
	s2[t].val = numbers[t];
    }

    qsort(s2, num, sizeof(posval_t), compare_pos);
    
    for(t=0;t<num;t++) {
	numbers[t] = s2[t].val;
	positions[t] = s2[t].pos + 1;
    }

    char filename[512];
    sprintf(filename, "%s/%s.numidx", dir,name);
    if(!writeIntArray(filename, numbers, num)) return 0;
    sprintf(filename, "%s/%s.numidx2", dir,name);
    if(!writeIntArray(filename, positions, num)) return 0;

    free(positions);
    free(numbers);
    free(s2);
    return PY_NONE;
}


static PyObject* f_verbose(PyObject* self, PyObject* args, PyObject* kwargs)
{
    static char *kwlist[] = {"verbose", NULL};
    int verbose;
    if (!PyArg_ParseTupleAndKeywords(args, kwargs, "i", kwlist, &verbose))
	return NULL;

    setVerbosity(verbose);
    return PY_NONE;
}

static PyMethodDef mgindexer_methods[] =
{
    /* module functions */

    {"verbose", (PyCFunction)f_verbose, METH_KEYWORDS, ""},

    {"makeindex", (PyCFunction)f_makeindex, METH_KEYWORDS, ""},
    {"makeNumIndex", (PyCFunction)f_makeNumIndex, METH_KEYWORDS, ""},
    {"makeClassIndex", (PyCFunction)f_makeClassIndex, METH_KEYWORDS, ""},

    {0, 0, 0, 0}
};

void initmgindexer(void)
{
    PyObject*module = Py_InitModule("mgindexer", mgindexer_methods);

    PyModule_AddObject(module, "SEPARATOR", PyString_FromString("\2"));
}

