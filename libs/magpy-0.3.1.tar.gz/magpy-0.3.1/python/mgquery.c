#include "sysfuncs.h"

#if defined(HAVE_SYS_PROCFS_H) && defined(HAVE_PR_BRKSIZE) && \
    (__STDC__ == 0)
/* STDC test was included to allow cc -Xc on SunOS 5 to work */
#define USE_PROCESS_MEM
#endif

#ifdef USE_PROCESS_MEM
# include <sys/procfs.h>
#endif

#ifdef HAVE_GETRUSAGE
# ifdef HAVE_SYS_TIME_H
#  include <sys/time.h>
# endif
# include <sys/resource.h>
#endif

#ifndef HAVE_GETPAGESIZE
# include "getpagesize.h"
#endif
 
#if WITH_REGEX
# include <regex.h>
#else
# include <rx.h>
#endif


#include <stdlib.h>
#include <stdarg.h>
#include <signal.h>

#include "messages.h"
#include "timing.h"
#include "memlib.h"

#include "filestats.h"
#include "invf.h"
#include "text.h"
#include "mg.h"
#include "lists.h"
#include "backend.h"
#include "environment.h"
#include "mg_errors.h"
#include "text_get.h"
#include "term_lists.h"

#include "words.h"
#include "mg_files.h"


static char *post_proc = NULL;

static void 
GetPostProc (char *line)
{
  char *start, *finish;
  if (post_proc)
    {
      Xfree (post_proc);
      post_proc = NULL;
    }
  start = strchr (line, '\"');
  finish = strrchr (line, '\"');
  if (start != finish)
    {
      /* found a pattern */
      *finish = '\0';
      post_proc = Xstrdup (start + 1);
      strcpy (start, finish + 1);
      if (BooleanEnv (GetEnv ("verbatim"), 1) == 0)
	{
	  char *s;
	  s = re_comp (post_proc);
	  if (s != NULL)    /* no error msg returned */
	    {
	      Xfree (post_proc);
	      post_proc = NULL;
	    }
	}
    }
  else if (start != NULL)
    {
      /* found a single speech mark. Delete It. */
      strcpy (start, start + 1);
    }
}

static void do_query (query_data*qd, char*query, char QueryType)
{
    char *line;
    ResetFileStats (qd);
    qd->max_mem_in_use = qd->mem_in_use = 0;
    qd->tot_hops_taken += qd->hops_taken;
    qd->tot_num_of_ptrs += qd->num_of_ptrs;
    qd->tot_num_of_accum += qd->num_of_accum;
    qd->tot_num_of_terms += qd->num_of_terms;
    qd->tot_num_of_ans += qd->num_of_ans;
    qd->tot_text_idx_lookups += qd->text_idx_lookups;
    qd->hops_taken = qd->num_of_ptrs = 0;
    qd->num_of_accum = qd->num_of_ans = qd->num_of_terms = 0;
    qd->text_idx_lookups = 0;

    if(!query)
	return;
    GetPostProc (query);
    FreeQueryDocs (qd);

    switch (QueryType)
      {
      case QUERY_BOOLEAN:
	{
	  char *maxdocs;
	  BooleanQueryInfo bqi;
	  maxdocs = GetDefEnv ("maxdocs", "all");
	  bqi.MaxDocsToRetrieve = strcmp (maxdocs, "all") ? atoi (maxdocs) : -1;
	  BooleanQuery (qd, query, &bqi);
	  break;
	}
      case QUERY_APPROX:
      case QUERY_RANKED:
	{
	  char *maxdocs;
	  char *maxterms;
	  char *maxaccum;
	  RankedQueryInfo rqi;
	  maxdocs = GetDefEnv ("maxdocs", "all");
	  maxterms = GetDefEnv ("max_terms", "all");
	  maxaccum = GetDefEnv ("max_accumulators", "all");
	  rqi.Sort = BooleanEnv (GetEnv ("sorted_terms"), 0);
	  rqi.QueryFreqs = BooleanEnv (GetEnv ("qfreq"), 1);
	  rqi.Exact = QueryType == QUERY_RANKED;
	  rqi.MaxDocsToRetrieve = strcmp (maxdocs, "all") ? atoi (maxdocs) : -1;
	  rqi.MaxTerms = strcmp (maxterms, "all") ? atoi (maxterms) : -1;
	  rqi.MaxParasToRetrieve = rqi.MaxDocsToRetrieve;
	  if (qd->id->ifh.InvfLevel == 3 && GetEnv ("maxparas"))
	    rqi.MaxParasToRetrieve = atoi (GetEnv ("maxparas"));
	  rqi.AccumMethod = toupper (*GetDefEnv ("accumulator_method", "A"));
	  rqi.MaxAccums = strcmp (maxaccum, "all") ? atoi (maxaccum) : -1;
	  rqi.HashTblSize = IntEnv (GetEnv ("hash_tbl_size"), 1000);
	  rqi.StopAtMaxAccum = BooleanEnv (GetEnv ("stop_at_max_accum"), 0);
	  rqi.skip_dump = GetEnv ("skip_dump");
	  RankedQuery (qd, query, &rqi);
	  break;
	}
      case QUERY_DOCNUMS:
	{
	  DocnumsQuery (qd, query);
	  break;
	}
      }

}


#ifndef MAIN

#undef _POSIX_C_SOURCE
#undef HAVE_LIMITS_H
#undef HAVE_STRFTIME
#undef HAVE_STRERROR
#undef HAVE_FTIME

#include <Python.h>
#include "intSet.h"

staticforward PyTypeObject MGSearchStoreClass;
staticforward PyTypeObject MGNumSearchStoreClass;
staticforward PyTypeObject MGQueryClass;

typedef struct {
    PyObject_HEAD
    InitQueryTimes iqt;
    query_data* qd;
    char*path;
    char*name;
    char*chars;
} MGSearchStoreObject;

typedef struct {
    PyObject_HEAD
    char*path;
    char*name;
    int num;
    int*positions;
    int*numbers;
} MGNumSearchStoreObject;

typedef struct {
    PyObject_HEAD
    int type;
    PyObject*store;
    char* query;
    int boolean;
    int from;
    int to;
} MGQueryObject;

static char* strf(char*format, ...)
{
    char buf[1024];
    int l;
    va_list arglist;
    va_start(arglist, format);
    vsprintf(buf, format, arglist);
    va_end(arglist);
    return strdup(buf);
}
#define PY_ERROR(s,args...) (PyErr_SetString(PyExc_Exception, strf(s, ## args)),NULL)
#define PY_NONE Py_BuildValue("s", 0)

//---------------------------------------------------------------------

staticforward PyObject* mgsearchstore_newquery(PyObject* _self, PyObject* args, PyObject* kwargs);
staticforward PyObject* mgnumsearchstore_newquery(PyObject* _self, PyObject* args, PyObject* kwargs);
staticforward PyObject* mgsearchstore_newbooleanquery(PyObject* _self, PyObject* args, PyObject* kwargs);
staticforward PyObject* mgsearchstore_getindex(PyObject* _self, PyObject* args, PyObject* kwargs);

static PyMethodDef MGSearchStore_methods[] =
{
    /* MGSearchStore functions */
    {"newQuery", (PyCFunction)mgsearchstore_newquery, METH_KEYWORDS, ""},
    {"newBooleanQuery", (PyCFunction)mgsearchstore_newbooleanquery, METH_KEYWORDS, ""},
    {"getIndex", (PyCFunction)mgsearchstore_getindex, METH_KEYWORDS, ""},
    {0,0,0,0}
};

static PyMethodDef MGNumSearchStore_methods[] =
{
    /* MGSearchStore functions */
    {"newQuery", (PyCFunction)mgnumsearchstore_newquery, METH_KEYWORDS, ""},
    {0,0,0,0}
};

static PyObject* f_MGSearchStore(PyObject* parent, PyObject* args, PyObject* kwargs)
{
    static char *kwlist[] = {"dir","name",NULL};
    char* dir=0, *name=0;
    if (!PyArg_ParseTupleAndKeywords(args, kwargs, "ss", kwlist, &dir, &name))
	return NULL;

    char filename[256];
    sprintf(filename, "%s/%s.numidx", dir,name);
    FILE*fi = fopen(filename, "rb");
    if(fi) {
	fclose(fi);
	/* numerical index, not mg */
	sprintf(filename, "%s/%s.numidx", dir,name);
	int numbers_num;
	int*numbers = readIntArray(filename, &numbers_num, 0);
	sprintf(filename, "%s/%s.numidx2", dir,name);
	int positions_num;
	int*positions = readIntArray(filename, &positions_num, 0);
	if(numbers_num!=positions_num)
	    return PY_ERROR("invalid .numidx/.numidx2");

	MGNumSearchStoreObject*self = PyObject_New(MGNumSearchStoreObject, &MGNumSearchStoreClass);
	self->path = strdup(dir);
	self->name = strdup(name);
	self->numbers = numbers;
	self->positions = positions;
	self->num = numbers_num;
	return (PyObject*)self;
    } else {
	char filename_chartab[256];
	sprintf(filename_chartab, "%s/%s.chartab", dir,name);

	MGSearchStoreObject*self = PyObject_New(MGSearchStoreObject, &MGSearchStoreClass);
	self->path = strdup(dir);
	self->name = strdup(name);
	self->chars = 0;
	
	fi = fopen(filename_chartab, "rb");
	if(fi) {
	    char*chars = malloc(256);
	    fread(chars, 1, 256, fi);
	    fclose(fi);
	    self->chars = chars;
	}

	InitEnv();

	self->qd = InitQuerySystem (dir, name, &self->iqt);
	if (!self->qd)
	  return PY_ERROR(mg_errorstrs[mg_errno], mg_error_data);
	
	return (PyObject*)self;
    }
}

static PyObject* mgsearchstore_getindex(PyObject* _self, PyObject* args, PyObject* kwargs)
{
    MGSearchStoreObject*self = (MGSearchStoreObject*)_self;
    static char *kwlist[] = {NULL};
    if (!PyArg_ParseTupleAndKeywords(args, kwargs, "", kwlist))
	return NULL;
      
    FILE *dict, *hash;
    unsigned long i;
    u_char prev[MAXSTEMLEN + 1];
    struct invf_dict_header idh;
    u_char *pool;
    int pool_left;

    set_basepath (self->path);
    dict = open_file (self->name, INVF_DICT_SUFFIX, "rb",
		      MAGIC_STEM_BUILD, MG_ABORT);

    fread ((char *) &idh, sizeof (idh), 1, dict);

    PyObject*list = PyList_New(idh.dict_size);

    for (i = 0; i < idh.dict_size; i++)
    {
	unsigned long copy, suff, l;
	unsigned long wcnt, fcnt;
	int len = 0;
	char tmpstr[MAXSTEMLEN + 1];

	/* build a new word on top of prev */
	copy = getc (dict);
	suff = getc (dict);
	len = copy + suff;
	
	if(fread (prev + copy, sizeof (u_char), suff, dict)<=0) {
	    //PyErr_SetFromErrno(PyObject *type)
	    perror("fread");return 0;
	}

	if(fread (&fcnt, sizeof (fcnt), 1, dict)<=0) {
	    perror("fread");return 0;
	}
	if(fread (&wcnt, sizeof (wcnt), 1, dict)<=0) {
	    perror("fread");return 0;
	}
	
	strncpy(tmpstr, prev, len);
	tmpstr[len] = 0;
	
	PyObject*item = PyTuple_New(2);
	PyTuple_SetItem(item, 0, PyString_FromString(tmpstr));
	PyTuple_SetItem(item, 1, PyInt_FromLong(fcnt));
	PyList_SetItem(list, i, item);
    }
    fclose (dict);
    return list;
}

#define TYPE_MG 0
#define TYPE_NUM 1

static PyObject* mgsearchstore_newquery(PyObject* _self, PyObject* args, PyObject* kwargs)
{
    char*query = 0;
    int boolean = 0;
    static char *kwlist[] = {"query","boolean",NULL};
    int t;
    if (!PyArg_ParseTupleAndKeywords(args, kwargs, "s|i", kwlist, &query, &boolean))
	return NULL;
    
    MGQueryObject*queryobj = PyObject_New(MGQueryObject, &MGQueryClass);
    queryobj->type = TYPE_MG;
    queryobj->store = _self;
    queryobj->query = strdup(query);
    queryobj->boolean = boolean;
    Py_INCREF(queryobj->store);
    return (PyObject*)queryobj;
}

static PyObject* mgnumsearchstore_newquery(PyObject* _self, PyObject* args, PyObject* kwargs)
{
    int from=-0x80000000,to=0x7fffffff;
    static char *kwlist2[] = {"fromto",NULL};
    static char *kwlist[] = {"from","to",NULL};
    char*fromto =0;
    int t;
    if (!PyArg_ParseTupleAndKeywords(args, kwargs, "s", kwlist2, &fromto)) {
        PyErr_Clear();
        if (!PyArg_ParseTupleAndKeywords(args, kwargs, "|ii", kwlist, &from, &to)) {
	    return NULL;
        }
    } else {
        char*x;
        fromto = strdup(fromto);
        x = strchr(fromto,'-');
        if(!x) {
            fprintf(stderr, "%s\n", fromto);
            return PY_ERROR("invalid <from>-<to> pattern");
        } else {
            *x = 0;
            from = atoi(fromto);
            to = atoi(x+1);
            free(fromto);
        }
    }
    
    MGQueryObject*queryobj = PyObject_New(MGQueryObject, &MGQueryClass);
    queryobj->type = TYPE_NUM;
    queryobj->store = _self;
    queryobj->query = 0;
    queryobj->boolean = 0;
    queryobj->from = from;
    queryobj->to = to;
    Py_INCREF(queryobj->store);
    return (PyObject*)queryobj;
}

static PyObject* mgsearchstore_newbooleanquery(PyObject* _self, PyObject* args, PyObject* kwargs)
{
    MGQueryObject*self = (MGQueryObject*)_self;
    char*query = 0;
    int boolean = 1;
    static char *kwlist[] = {"query",NULL};
    int t;
    if (!PyArg_ParseTupleAndKeywords(args, kwargs, "s", kwlist, &query))
	return NULL;
    
    MGQueryObject*queryobj = PyObject_New(MGQueryObject, &MGQueryClass);
    queryobj->type = TYPE_MG;
    queryobj->store = _self;
    queryobj->query = strdup(query);
    queryobj->boolean = boolean;
    Py_INCREF(queryobj->store);
    return (PyObject*)queryobj;
}

static void MGSearchStore_dealloc(PyObject* _self) {
    MGSearchStoreObject* self = (MGSearchStoreObject*)_self;

    FinishQuerySystem(self->qd);
    if(self->path) {
	free(self->path);self->path = 0;
    }
    if(self->name) {
	free(self->name);self->name = 0;
    }
    if(self->chars) {
	free(self->chars);self->chars = 0;
    }
    
    PyObject_Del(self);
}
static void MGNumSearchStore_dealloc(PyObject* _self) {
    MGNumSearchStoreObject* self = (MGNumSearchStoreObject*)_self;
    if(self->path) {
	free(self->path);self->path = 0;
    }
    if(self->name) {
	free(self->name);self->name = 0;
    }
    if(self->numbers) {
	free(self->numbers);self->numbers = 0;
    }
    if(self->positions) {
	free(self->positions);self->positions = 0;
    }
    PyObject_Del(self);
}
static PyObject* MGSearchStore_getattr(PyObject * _self, char* a)
{
    MGSearchStoreObject*self = (MGSearchStoreObject*)_self;
    return Py_FindMethod(MGSearchStore_methods, _self, a);
}
static PyObject* MGNumSearchStore_getattr(PyObject * _self, char* a)
{
    MGNumSearchStoreObject*self = (MGNumSearchStoreObject*)_self;
    return Py_FindMethod(MGNumSearchStore_methods, _self, a);
}
static int MGSearchStore_setattr(PyObject * _self, char* a, PyObject * o) 
{
    MGSearchStoreObject*self = (MGSearchStoreObject*)_self;
    return -1;
}
static int MGNumSearchStore_setattr(PyObject * _self, char* a, PyObject * o) 
{
    MGNumSearchStoreObject*self = (MGNumSearchStoreObject*)_self;
    return -1;
}
static int MGSearchStore_print(PyObject * _self, FILE *fi, int flags)
{
    MGSearchStoreObject*self = (MGSearchStoreObject*)_self;
    fprintf(fi, "<searchstore %08x(%d) path=%s name=%s>", (int)_self, _self?_self->ob_refcnt:0, self->path, self->name);
    return 0;
}
static int MGNumSearchStore_print(PyObject * _self, FILE *fi, int flags)
{
    MGNumSearchStoreObject*self = (MGNumSearchStoreObject*)_self;
    fprintf(fi, "<searchstore %08x(%d) path=%s name=%s>", (int)_self, _self?_self->ob_refcnt:0, self->path, self->name);
    return 0;
}

//---------------------------------------------------------------------

staticforward PyObject* mgquery_words(PyObject* _self, PyObject* args, PyObject* kwargs);
staticforward PyObject* mgquery_execute(PyObject* _self, PyObject* args, PyObject* kwargs);
staticforward PyObject* mgquery_intset(PyObject* _self, PyObject* args, PyObject* kwargs);

static PyMethodDef MGQuery_methods[] =
{
    /* MGQuery functions */
    {"execute", (PyCFunction)mgquery_execute, METH_KEYWORDS, ""},
    {"intset", (PyCFunction)mgquery_intset, METH_KEYWORDS, ""},
    {"words", (PyCFunction)mgquery_words, METH_KEYWORDS, ""},
    {0,0,0,0}
};

static PyObject* mgquery_execute(PyObject* _self, PyObject* args, PyObject* kwargs)
{
    MGQueryObject*self = (MGQueryObject*)_self;
    static char *kwlist[] = {NULL};
    int t;
    if (!PyArg_ParseTupleAndKeywords(args, kwargs, "", kwlist))
	return NULL;

    MGSearchStoreObject* store = (MGSearchStoreObject*)self->store;

    if(store->chars) {
	setAllowedCharacters(store->chars);
    }

    do_query(store->qd, self->query, self->boolean?QUERY_BOOLEAN:QUERY_RANKED);
      
    PyObject*list = PyList_New(store->qd->DL->num);
    for(t=0;t<store->qd->DL->num;t++) {
	DocEntry*e = &store->qd->DL->DE[t];
	int num = e->DocNum;
	double weight = e->Weight;
	PyObject*item = PyTuple_New(2);
	PyTuple_SetItem(item, 0, PyInt_FromLong(num));
	PyTuple_SetItem(item, 1, PyFloat_FromDouble(weight));
	PyList_SetItem(list, t, item);
    }
    return list;
}

static PyObject* mgquery_intset(PyObject* _self, PyObject* args, PyObject* kwargs)
{
    MGQueryObject*self = (MGQueryObject*)_self;
    static char *kwlist[] = {NULL};
    int t;
    if (!PyArg_ParseTupleAndKeywords(args, kwargs, "", kwlist))
	return NULL;

    if(self->type==TYPE_MG) {
	MGSearchStoreObject* store = (MGSearchStoreObject*)self->store;
	if(store->chars) {
	    setAllowedCharacters(store->chars);
	}
	do_query(store->qd, self->query, self->boolean?QUERY_BOOLEAN:QUERY_RANKED);
	 
	int*list = malloc(sizeof(int)*store->qd->DL->num);
	for(t=0;t<store->qd->DL->num;t++) {
	    DocEntry*e = &store->qd->DL->DE[t];
	    int num = e->DocNum;
	    list[t] = num;
	}
	return intSet_fromarray(list, store->qd->DL->num);
    } else {
	MGNumSearchStoreObject* store = (MGNumSearchStoreObject*)self->store;
	int t;
        int min,max,i,l;
	int first = 0x7fffffff, last = -0x80000000;
	int num = 0;
        int len = store->num;
	int* list;

#define BINARY
#ifndef BINARY
	for(t=0;t<len;t++) {
	    if(store->numbers[t] >= self->from && first==0x7fffffff)
		first = t;
	    if(store->numbers[t] <= self->to)
		last = t;
	}
#else
        for(min=0, max=len, i=max/2, l=max; i != l; l=i, i=(min+max)/2) {
            if(store->numbers[i] >= self->from) max=i;
            else min=i+1;
        }
        first = i;

        for(min=0, max=len, i=max/2, l=max; i != l; l=i, i=(min+max)/2) {
            if(store->numbers[i] <= self->to) min=i;
            else max=i;
        }
        last = i;
#endif

	if(first <= last && last < len) {
	    num = last - first + 1;
	    list = malloc(sizeof(int)*num);
	    memcpy(list, &store->positions[first], sizeof(int)*num);
	    return intSet_fromarray(list, num);
	}
	return intSet_fromarray(0, 0);
    }
}

char*mystrndup(char*src, int len)
{
    int srclen = strlen(src);

    if(srclen > len) {
        char*dest = (char*)malloc(len+1);
        memcpy(dest, src, len);
        dest[len] = 0;
        return dest;
    } else {
        return strdup(src);
    }
}

static PyObject* mgquery_words(PyObject* _self, PyObject* args, PyObject* kwargs)
{
    MGQueryObject*self = (MGQueryObject*)_self;
    MGSearchStoreObject* store = (MGSearchStoreObject*)self->store;
    static char *kwlist[] = {NULL};
    int t;
    if (!PyArg_ParseTupleAndKeywords(args, kwargs, "", kwlist))
	return NULL;

    if(!self->query) {
	//return PY_ERROR("word extraction not supported for this kind of query");
        PyObject*list = PyList_New(0);
        return list;
    }
	
    if(store->chars) {
	setAllowedCharacters(store->chars);
    }

    /* TODO: do we really need to run a query to parse the query words? 
    
    Or does
	store->qd->TL = ParseRankedQuery (store->qd->sd, self->query, BooleanEnv (GetEnv ("sorted_terms"), 0));
    work, too?
     */
    do_query(store->qd, self->query, self->boolean?QUERY_BOOLEAN:QUERY_RANKED);

    int num = store->qd->TL->num;
    //printf("query: %s\n", self->query);
    
    PyObject*list = PyList_New(num);
    for(t=0;t<store->qd->TL->num;t++) {
	unsigned char *word = store->qd->TL->TE[t].Word;
	int len = word[0];
	char* s = (char*)mystrndup(word+1, len);
	//printf("word %d: %s\n", t, s);
	PyList_SetItem(list, t, PyString_FromString(s));
	free(s);
    }

    return list;
}

static void MGQuery_dealloc(PyObject* _self) {
    MGQueryObject* self = (MGQueryObject*)_self;

    if(self->store) {
	Py_DECREF(self->store);
	self->store = 0;
    }
    if(self->query) {
	free(self->query);
	self->query = 0;
    }
    self->boolean = 0;
    PyObject_Del(self);
}
static PyObject* MGQuery_getattr(PyObject * _self, char* a)
{
    MGQueryObject*self = (MGQueryObject*)_self;
    return Py_FindMethod(MGQuery_methods, _self, a);
}
static int MGQuery_setattr(PyObject * _self, char* a, PyObject * o) 
{
    MGQueryObject*self = (MGQueryObject*)_self;
    return -1;
}
static int MGQuery_print(PyObject * _self, FILE *fi, int flags)
{
    MGQueryObject*self = (MGQueryObject*)_self;
    fprintf(fi, "<query %08x(%d) \"%s\">", (int)_self, _self?_self->ob_refcnt:0, self->query);
    return 0;
}

//---------------------------------------------------------------------

static PyTypeObject MGSearchStoreClass =
{
    PyObject_HEAD_INIT(NULL)
    0,
    tp_name: "MGSearchStore",
    tp_basicsize: sizeof(MGSearchStoreObject),
    tp_itemsize: 0,
    tp_dealloc: MGSearchStore_dealloc,
    tp_print: MGSearchStore_print,
    tp_getattr: MGSearchStore_getattr,
    tp_setattr: MGSearchStore_setattr,
};

//---------------------------------------------------------------------

static PyTypeObject MGQueryClass =
{
    PyObject_HEAD_INIT(NULL)
    0,
    tp_name: "MGQuery",
    tp_basicsize: sizeof(MGQueryObject),
    tp_itemsize: 0,
    tp_dealloc: MGQuery_dealloc,
    tp_print: MGQuery_print,
    tp_getattr: MGQuery_getattr,
    tp_setattr: MGQuery_setattr,
};

static PyTypeObject MGNumSearchStoreClass =
{
    PyObject_HEAD_INIT(NULL)
    0,
    tp_name: "MGNumSearchStore",
    tp_basicsize: sizeof(MGSearchStoreObject),
    tp_itemsize: 0,
    tp_dealloc: MGNumSearchStore_dealloc,
    tp_print: MGNumSearchStore_print,
    tp_getattr: MGNumSearchStore_getattr,
    tp_setattr: MGNumSearchStore_setattr,
};

//=====================================================================

static PyObject* f_verbose(PyObject* self, PyObject* args, PyObject* kwargs)
{
    static char *kwlist[] = {NULL};
    int verbose;
    if (!PyArg_ParseTupleAndKeywords(args, kwargs, "i", kwlist, &verbose))
	return NULL;
    return NULL;
}

static PyMethodDef mgquery_methods[] =
{
    /* module functions */
    {"verbose", (PyCFunction)f_verbose, METH_KEYWORDS, "set the module verbosity (0=quiet)"},
    {"MGSearchStore", (PyCFunction)f_MGSearchStore, METH_KEYWORDS, "Create a new search store"},
    {"MGSearchResult", (PyCFunction)f_makeIntSet, METH_KEYWORDS, "Create a new search result object"},
    {0, 0, 0, 0}
};

void initmgquery(void)
{
    initintSet();
    MGSearchStoreClass.ob_type = &PyType_Type;
    MGNumSearchStoreClass.ob_type = &PyType_Type;
    MGQueryClass.ob_type = &PyType_Type;
    PyObject*module = Py_InitModule("mgquery", mgquery_methods);
}
#endif

#ifdef MAIN
int main()
{
    void*dummy = malloc(4096);
    InitQueryTimes iqt;
    InitEnv();
    query_data* qd = InitQuerySystem ("data/bvb", "bvb", &iqt);
    do_query(qd, "traktor", QUERY_RANKED);
}
#endif
