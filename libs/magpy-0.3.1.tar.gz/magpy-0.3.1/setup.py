#!/usr/bin/env python

"""Setup script for the magpy module distribution."""

__revision__ = "$Id: setup.py,v 1.3 2006/03/01 13:43:29 kramm Exp $"

from distutils.core import setup,Extension
import os
from version import VERSION

debug = 0
if "DISTUTILS_DEBUG" in os.environ:
    debug = 1


OBJS_LIBS= \
["lib/alloca.c", "lib/bitio_gen.c", "lib/bitio_mem.c", "lib/bitio_mems.c", "lib/bitio_random.c", "lib/bitio_stdio.c",  \
 "lib/error.c", "lib/filestats.c", "lib/ftruncate.c", "lib/getopt.c", "lib/getopt1.c", "lib/heap.c", "lib/huffman.c", \
 "lib/huffman_mem.c", "lib/huffman_stdio.c", "lib/local_strings.c", "lib/memlib.c", "lib/messages.c", "lib/perf_hash.c", \
 "lib/random.c", "lib/rx.c", "lib/sptree.c", "lib/stem.c", "lib/strcasecmp.c", "lib/strstr.c", "lib/timing.c", "lib/xmalloc.c", "lib/quicksort.c",
]
OBJS_PASSES= \
["src/ivf.pass1.c", "src/ivf.pass2.c", "src/text.pass1.c", "src/text.pass2.c"]

OBJS_COMMON= \
["src/locallib.c", "src/comp_dict.c", "src/mg.special.c", "src/mg_files.c","src/lists.c","src/mg_errors.c","src/stemmer.c","src/memwatch.c","src/words.c"]

OBJS_QUERY= \
["src/backend.c", "src/bool_query.c", "src/query.ranked.c", "src/query.docnums.c"]

OBJS_QUERY2= \
["src/bool_parser.c", "src/bool_tree.c", "src/stem_search.c", "src/environment.c",
 "src/weights.c", "src/text_get.c", "src/invf_get.c", "src/term_lists.c", "src/bool_optimiser.c"]

OBJS_COMMANDS= \
["commands/mg_passes.c", "commands/mg_perf_hash_build.c", "commands/mg_weights_build.c", 
 "commands/mg_compression_dict.c", "commands/mgstat.c", "commands/mg_invf_dict.c"]

setup (# Distribution meta-data
       name = "magpy",
       version = VERSION,
       description = "MG search engine module",
       author = "Matthias Kramm",
       author_email = "kramm@quiss.org",
       url = "http://www.athana.org/magpy/",

       # Description of the modules and packages in the distribution
       py_modules = [],
       ext_modules = [ Extension("mgquery",
                       ["python/mgquery.c", "python/intSet.c"] + OBJS_LIBS + OBJS_QUERY + OBJS_QUERY2 + OBJS_COMMON,
                       include_dirs=["src","lib","."],
                       library_dirs=[],
                       libraries=[],
                       extra_compile_args=["-DHAVE_CONFIG_H"],
                       extra_link_args="",
                      ),
                      Extension("mgindexer",
                       ["python/mgindexer.c", "python/intSet.c"] + OBJS_LIBS + OBJS_COMMON + OBJS_PASSES + OBJS_COMMANDS, #sourcefiles
                       include_dirs=["src","lib","."],
                       library_dirs=[],
                       libraries=[],
                       extra_compile_args=["-DHAVE_CONFIG_H"],
                       extra_link_args="",
                      )]
      )

