#ifndef __memwatch_h__
#define __memwatch_h__

typedef struct _memchunk {
    void*data;
    struct _memchunk* next;
} memchunk_t;

typedef struct _memchain {
    struct _memchunk* first;
    struct _memchunk* next;
} memchain_t;



memchain_t* memchain_create(void*data);
void memchain_add(memchain_t*m, void*data);
void memchain_free(memchain_t*m);

#endif //__memwatch_h__
