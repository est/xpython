#include <stdlib.h>
#include <stdio.h>
#include <memory.h>
#include "memwatch.h"

void memchain_add(memchain_t*m, void*data)
{
    memchunk_t*n = malloc(sizeof(memchunk_t));
    memset(n, 0, sizeof(memchunk_t));
    n->data = data;

    if(!m->next) {
	m->next = m->first = n;
    } else {
	m->next->next = n;
	m->next = n;
    }
}

memchain_t* memchain_create(void*data)
{
    memchain_t* m = (memchain_t*)malloc(sizeof(memchain_t));
    memset(m, 0, sizeof(memchain_t));
    if(data) {
	memchain_add(m, data);
    }
    return m;
}


void memchain_free(memchain_t*m)
{
    memchunk_t*c = m->first;
    while(c) {
	memchunk_t*next = c->next; c->next = 0;
	free(c->data);c->data = 0;
	free(c);
	c = next;
    }
    free(m);
}
